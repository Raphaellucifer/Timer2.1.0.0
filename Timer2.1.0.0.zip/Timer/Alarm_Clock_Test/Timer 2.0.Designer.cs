﻿namespace Alarm_Clock_Test
{
    partial class frmTimer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmTimer));
            this.shaperForm = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.notifyIcon = new System.Windows.Forms.NotifyIcon(this.components);
            this.panelTop = new System.Windows.Forms.Panel();
            this.btnExit = new Bunifu.Framework.UI.BunifuImageButton();
            this.lblMainName = new System.Windows.Forms.Label();
            this.frmMainDragControl = new Bunifu.Framework.UI.BunifuDragControl(this.components);
            this.lblName = new System.Windows.Forms.Label();
            this.lblWelcome = new System.Windows.Forms.Label();
            this.btnStart = new Bunifu.Framework.UI.BunifuThinButton2();
            this.btnStop = new Bunifu.Framework.UI.BunifuThinButton2();
            this.timePicker = new System.Windows.Forms.DateTimePicker();
            this.lblStatus = new System.Windows.Forms.Label();
            this.lblReady = new System.Windows.Forms.Label();
            this.btnGo = new Bunifu.Framework.UI.BunifuThinButton2();
            this.panelTop.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnExit)).BeginInit();
            this.SuspendLayout();
            // 
            // shaperForm
            // 
            this.shaperForm.ElipseRadius = 15;
            this.shaperForm.TargetControl = this;
            // 
            // notifyIcon
            // 
            this.notifyIcon.BalloonTipIcon = System.Windows.Forms.ToolTipIcon.Info;
            this.notifyIcon.BalloonTipText = "Your timer has been initialized";
            this.notifyIcon.BalloonTipTitle = "Hey There!";
            this.notifyIcon.Icon = ((System.Drawing.Icon)(resources.GetObject("notifyIcon.Icon")));
            this.notifyIcon.Text = "Hey there, You have started me.";
            this.notifyIcon.Visible = true;
            // 
            // panelTop
            // 
            this.panelTop.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.panelTop.Controls.Add(this.btnExit);
            this.panelTop.Controls.Add(this.lblMainName);
            this.panelTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTop.Location = new System.Drawing.Point(0, 0);
            this.panelTop.Name = "panelTop";
            this.panelTop.Size = new System.Drawing.Size(600, 41);
            this.panelTop.TabIndex = 0;
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.Color.Transparent;
            this.btnExit.Image = ((System.Drawing.Image)(resources.GetObject("btnExit.Image")));
            this.btnExit.ImageActive = null;
            this.btnExit.Location = new System.Drawing.Point(7, 5);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(30, 30);
            this.btnExit.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.btnExit.TabIndex = 1;
            this.btnExit.TabStop = false;
            this.btnExit.Zoom = 10;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // lblMainName
            // 
            this.lblMainName.AutoSize = true;
            this.lblMainName.BackColor = System.Drawing.Color.Transparent;
            this.lblMainName.Font = new System.Drawing.Font("Poppins", 16F);
            this.lblMainName.Location = new System.Drawing.Point(446, 4);
            this.lblMainName.Name = "lblMainName";
            this.lblMainName.Size = new System.Drawing.Size(151, 39);
            this.lblMainName.TabIndex = 0;
            this.lblMainName.Text = "T I M E R 2 . 0";
            // 
            // frmMainDragControl
            // 
            this.frmMainDragControl.Fixed = true;
            this.frmMainDragControl.Horizontal = true;
            this.frmMainDragControl.TargetControl = this.panelTop;
            this.frmMainDragControl.Vertical = true;
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Font = new System.Drawing.Font("Poppins", 18F);
            this.lblName.Location = new System.Drawing.Point(178, 93);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(245, 42);
            this.lblName.TabIndex = 1;
            this.lblName.Text = "T   I   M   E   R   2   .   0";
            // 
            // lblWelcome
            // 
            this.lblWelcome.AutoSize = true;
            this.lblWelcome.Location = new System.Drawing.Point(122, 65);
            this.lblWelcome.Name = "lblWelcome";
            this.lblWelcome.Size = new System.Drawing.Size(356, 28);
            this.lblWelcome.TabIndex = 1;
            this.lblWelcome.Text = "Welcome to the new version of our protocol";
            // 
            // btnStart
            // 
            this.btnStart.ActiveBorderThickness = 1;
            this.btnStart.ActiveCornerRadius = 20;
            this.btnStart.ActiveFillColor = System.Drawing.Color.Crimson;
            this.btnStart.ActiveForecolor = System.Drawing.Color.White;
            this.btnStart.ActiveLineColor = System.Drawing.Color.White;
            this.btnStart.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.btnStart.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnStart.BackgroundImage")));
            this.btnStart.ButtonText = "S T A R T";
            this.btnStart.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnStart.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnStart.ForeColor = System.Drawing.Color.Crimson;
            this.btnStart.IdleBorderThickness = 1;
            this.btnStart.IdleCornerRadius = 10;
            this.btnStart.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(28)))), ((int)(((byte)(28)))));
            this.btnStart.IdleForecolor = System.Drawing.Color.Crimson;
            this.btnStart.IdleLineColor = System.Drawing.Color.Crimson;
            this.btnStart.Location = new System.Drawing.Point(85, 215);
            this.btnStart.Margin = new System.Windows.Forms.Padding(5);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(181, 39);
            this.btnStart.TabIndex = 3;
            this.btnStart.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // btnStop
            // 
            this.btnStop.ActiveBorderThickness = 1;
            this.btnStop.ActiveCornerRadius = 20;
            this.btnStop.ActiveFillColor = System.Drawing.Color.SpringGreen;
            this.btnStop.ActiveForecolor = System.Drawing.Color.White;
            this.btnStop.ActiveLineColor = System.Drawing.Color.White;
            this.btnStop.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.btnStop.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnStop.BackgroundImage")));
            this.btnStop.ButtonText = "S T O P";
            this.btnStop.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnStop.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnStop.ForeColor = System.Drawing.Color.SpringGreen;
            this.btnStop.IdleBorderThickness = 1;
            this.btnStop.IdleCornerRadius = 10;
            this.btnStop.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(28)))), ((int)(((byte)(28)))));
            this.btnStop.IdleForecolor = System.Drawing.Color.SpringGreen;
            this.btnStop.IdleLineColor = System.Drawing.Color.SpringGreen;
            this.btnStop.Location = new System.Drawing.Point(334, 215);
            this.btnStop.Margin = new System.Windows.Forms.Padding(5);
            this.btnStop.Name = "btnStop";
            this.btnStop.Size = new System.Drawing.Size(181, 39);
            this.btnStop.TabIndex = 3;
            this.btnStop.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnStop.Click += new System.EventHandler(this.btnStop_Click);
            // 
            // timePicker
            // 
            this.timePicker.CalendarFont = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.timePicker.CalendarForeColor = System.Drawing.Color.LightSalmon;
            this.timePicker.CalendarMonthBackground = System.Drawing.Color.DimGray;
            this.timePicker.CalendarTitleBackColor = System.Drawing.Color.White;
            this.timePicker.CalendarTitleForeColor = System.Drawing.Color.White;
            this.timePicker.CalendarTrailingForeColor = System.Drawing.Color.White;
            this.timePicker.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.timePicker.Font = new System.Drawing.Font("Century Gothic", 10F);
            this.timePicker.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.timePicker.Location = new System.Drawing.Point(210, 138);
            this.timePicker.Name = "timePicker";
            this.timePicker.Size = new System.Drawing.Size(180, 24);
            this.timePicker.TabIndex = 4;
            // 
            // lblStatus
            // 
            this.lblStatus.AutoSize = true;
            this.lblStatus.Location = new System.Drawing.Point(269, 172);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(62, 28);
            this.lblStatus.TabIndex = 1;
            this.lblStatus.Text = "Status";
            // 
            // lblReady
            // 
            this.lblReady.AutoSize = true;
            this.lblReady.Location = new System.Drawing.Point(266, 90);
            this.lblReady.Name = "lblReady";
            this.lblReady.Size = new System.Drawing.Size(68, 28);
            this.lblReady.TabIndex = 6;
            this.lblReady.Text = "Ready!";
            // 
            // btnGo
            // 
            this.btnGo.ActiveBorderThickness = 1;
            this.btnGo.ActiveCornerRadius = 20;
            this.btnGo.ActiveFillColor = System.Drawing.Color.Firebrick;
            this.btnGo.ActiveForecolor = System.Drawing.Color.White;
            this.btnGo.ActiveLineColor = System.Drawing.Color.White;
            this.btnGo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.btnGo.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnGo.BackgroundImage")));
            this.btnGo.ButtonText = "Go   >>>>>";
            this.btnGo.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnGo.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGo.ForeColor = System.Drawing.Color.Firebrick;
            this.btnGo.IdleBorderThickness = 1;
            this.btnGo.IdleCornerRadius = 10;
            this.btnGo.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(28)))), ((int)(((byte)(28)))));
            this.btnGo.IdleForecolor = System.Drawing.Color.Firebrick;
            this.btnGo.IdleLineColor = System.Drawing.Color.Firebrick;
            this.btnGo.Location = new System.Drawing.Point(210, 137);
            this.btnGo.Margin = new System.Windows.Forms.Padding(5);
            this.btnGo.Name = "btnGo";
            this.btnGo.Size = new System.Drawing.Size(181, 39);
            this.btnGo.TabIndex = 3;
            this.btnGo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnGo.Click += new System.EventHandler(this.btnGo_Click);
            // 
            // frmTimer
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.ClientSize = new System.Drawing.Size(600, 267);
            this.Controls.Add(this.lblReady);
            this.Controls.Add(this.btnGo);
            this.Controls.Add(this.timePicker);
            this.Controls.Add(this.btnStop);
            this.Controls.Add(this.btnStart);
            this.Controls.Add(this.lblWelcome);
            this.Controls.Add(this.lblStatus);
            this.Controls.Add(this.lblName);
            this.Controls.Add(this.panelTop);
            this.Font = new System.Drawing.Font("Poppins", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.White;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmTimer";
            this.Opacity = 0.9D;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Timer 2.0";
            this.Load += new System.EventHandler(this.frmTimer_Load);
            this.panelTop.ResumeLayout(false);
            this.panelTop.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnExit)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Bunifu.Framework.UI.BunifuElipse shaperForm;
        private System.Windows.Forms.NotifyIcon notifyIcon;
        private System.Windows.Forms.Panel panelTop;
        private Bunifu.Framework.UI.BunifuDragControl frmMainDragControl;
        private Bunifu.Framework.UI.BunifuImageButton btnExit;
        private System.Windows.Forms.Label lblMainName;
        private System.Windows.Forms.Label lblWelcome;
        private System.Windows.Forms.Label lblName;
        private Bunifu.Framework.UI.BunifuThinButton2 btnStart;
        private Bunifu.Framework.UI.BunifuThinButton2 btnStop;
        private System.Windows.Forms.DateTimePicker timePicker;
        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.Label lblReady;
        private Bunifu.Framework.UI.BunifuThinButton2 btnGo;
    }
}

