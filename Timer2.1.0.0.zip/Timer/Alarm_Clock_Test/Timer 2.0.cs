﻿using System;
using System.Drawing;
using System.Media;
using System.Timers;
using System.Windows.Forms;

namespace Alarm_Clock_Test
{
    public partial class frmTimer : Form
    {
        System.Timers.Timer timer;
        delegate void UpdateLabel(Label lbl, string value);

        public frmTimer()
        {
            InitializeComponent();
            lblStatus.Visible = false;
            lblWelcome.Visible = false;
            lblReady.Visible = true;
            lblName.Visible = false;
            btnStart.Visible = false;
            btnStop.Visible = false;
            btnGo.Visible = true;
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void frmTimer_Load(object sender, EventArgs e)
        {
             timer = new System.Timers.Timer();
             timer.Interval = 1000;
             timer.Elapsed += Timer_Elapsed;

        }

        void UpdateDataLabel(Label lbl, string value)
        {
            lbl.Text = value;  
        }

        private void Timer_Elapsed(object sender, ElapsedEventArgs e)
        {
            var currentTime = DateTime.Now;
            var userTime = timePicker.Value;

            // This is stop code.
            if (currentTime.Hour == userTime.Hour && currentTime.Minute == userTime.Minute && currentTime.Second == userTime.Second)
            {
                timer.Stop();
                
                try
                {
                    UpdateLabel upd = UpdateDataLabel;
                    var player = new SoundPlayer();

                    lblStatus.Visible = true;
                    lblStatus.Location = new Point(218, 172);
                    lblStatus.Text = "Timer has stopped.";

                    notifyIcon.ShowBalloonTip(10000000, "Hey There!", "Timer is Done", ToolTipIcon.Info);

                    
                    player.SoundLocation = @"C:\Windows\media\Alarm03.wav";  // Locaion of the tone.
                   
                    for (int i = 0; i < 5; i++)
                    {
                        player.Play();
                    }
                }
                catch (Exception exception)
                {
                    MessageBox.Show(exception.Message, "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            timer.Start();
           
            lblStatus.Visible = true;
            lblStatus.Location = new Point(119, 172);
            lblStatus.Text = "Timer is running. I'll notify you when I'm done.";

            notifyIcon.ShowBalloonTip(10000000);
        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            timer.Stop();
           
            lblStatus.Visible = true;
            lblStatus.Location = new Point(218, 172);
            lblStatus.Text = "Timer has stopped.";

            notifyIcon.ShowBalloonTip(10000000, "Hey There!", "You have stopped the timer", ToolTipIcon.Warning);

        }

        private void btnGo_Click(object sender, EventArgs e)
        {
            lblStatus.Visible = false;
            lblWelcome.Visible = true;
            lblReady.Visible = false;
            lblName.Visible = true;
            btnStart.Visible = true;
            btnStop.Visible = true;
            btnGo.Visible = false;
        }
    }
}
